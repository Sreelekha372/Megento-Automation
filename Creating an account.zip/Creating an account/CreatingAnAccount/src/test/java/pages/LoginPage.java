package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    WebDriver driver;

    private By email = By.id("email");
    private By password = By.id("pass");
    private By signInBtn = By.id("send2");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void open() {
        driver.get("https://magento.softwaretestingboard.com/customer/account/login/");
    }

    public void login(String mail, String pwd) {
        driver.findElement(email).sendKeys(mail);
        driver.findElement(password).sendKeys(pwd);
        driver.findElement(signInBtn).click();
    }




}
