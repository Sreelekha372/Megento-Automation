package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ChangePasswordPage {
    WebDriver driver;

    private By changePwdCheckbox = By.id("change-password");
    private By currentPwd = By.id("current-password");
    private By newPwd = By.id("password");
    private By confirmPwd = By.id("password-confirmation");
    private By saveBtn = By.cssSelector("button.save");

    public ChangePasswordPage(WebDriver driver) {
        this.driver = driver;
    }


    public void open() {
        driver.get("https://magento.softwaretestingboard.com/customer/account/edit/");
    }

    public void changePassword(String oldPass, String newPass) {
        driver.findElement(changePwdCheckbox).click();
        driver.findElement(currentPwd).sendKeys(oldPass);
        driver.findElement(newPwd).sendKeys(newPass);
        driver.findElement(confirmPwd).sendKeys(newPass);
        driver.findElement(saveBtn).click();
    }
}
