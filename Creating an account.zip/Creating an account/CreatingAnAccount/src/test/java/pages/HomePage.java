package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class HomePage {
    WebDriver driver;

    private By accountMenu = By.cssSelector("button[data-action='customer-menu-toggle']");
    private By signOut = By.linkText("Sign Out");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void signOut() {
        driver.findElement(accountMenu).click();
        driver.findElement(signOut).click();
    }
}
