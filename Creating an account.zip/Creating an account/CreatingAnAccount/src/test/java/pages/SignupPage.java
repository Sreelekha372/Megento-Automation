package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SignupPage {
    WebDriver driver;
    private By firstName = By.id("firstname");
    private By lastName = By.id("lastname");
    private By email = By.id("email_address");
    private By password = By.id("password");
    private By confirmPassword = By.id("password-confirmation");
    private By createAccountBtn = By.cssSelector("button[title='Create an Account']");

    public SignupPage(WebDriver driver) {
        this.driver = driver;
    }

    public void open() {
        driver.get("https://magento.softwaretestingboard.com/customer/account/create/");
    }

    public void register(String fName, String lName, String mail, String pwd) {
        driver.findElement(firstName).sendKeys(fName);
        driver.findElement(lastName).sendKeys(lName);
        driver.findElement(email).sendKeys(mail);
        driver.findElement(password).sendKeys(pwd);
        driver.findElement(confirmPassword).sendKeys(pwd);
        driver.findElement(createAccountBtn).click();
    }


}
