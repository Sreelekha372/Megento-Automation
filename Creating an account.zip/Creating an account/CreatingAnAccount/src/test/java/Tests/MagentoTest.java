package Tests;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.Assert;
import org.testng.annotations.*;
import pages.*;
import java.time.Duration;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;





public class MagentoTest {

    WebDriver driver;

   SignupPage signupPage;
    LoginPage loginPage;
    HomePage homePage;
   ChangePasswordPage changePasswordPage;

    String firstName = "Test";
    String lastName = "User";
    String email = "user" + System.currentTimeMillis() + "@mail.com";
    String password = "Test@1234";
    String newPassword = "Test@5678";

    @BeforeClass
    public void setUp() {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\T480\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver= new ChromeDriver();

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        signupPage = new SignupPage(driver);
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        changePasswordPage = new ChangePasswordPage(driver);
    }

    @Test(priority = 1)
    public void testSignup() {
        signupPage.open();
        signupPage.register(firstName, lastName, email, password);
        Assert.assertTrue(driver.getPageSource().contains("Thank you for registering"), "Sign up failed!");
    }


    @Test(priority = 2)
    public void testLogin() {
        loginPage.open();
        loginPage.login(email, password);
        Assert.assertTrue(driver.getPageSource().contains("My Account"), "Login failed!");
    }


    @Test(priority = 3)
    public void testSignOut() {
        homePage.signOut();
        Assert.assertTrue(driver.getPageSource().contains("You are signed out"), "Sign out failed!");
    }

    @Test(priority = 4)
    public void testChangePassword() {
        // login first
        loginPage.open();
        loginPage.login(email, password);
        Assert.assertTrue(driver.getPageSource().contains("My Account"));

        // change password
        changePasswordPage.open();
        changePasswordPage.changePassword(password, newPassword);
        Assert.assertTrue(driver.getPageSource().contains("The account information has been saved"), "Change password failed!");

        // sign out and login with new password
        homePage.signOut();
        loginPage.open();
        loginPage.login(email, newPassword);
        Assert.assertTrue(driver.getPageSource().contains("My Account"), "Login with new password failed!");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
